
public class Acces implements Runnable {
public Interfaces inter;
	public Acces(Interfaces location) {
		// TODO Auto-generated constructor stub
		inter = location;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
