import java.net.Socket;


public class Communication implements Runnable {

	Socket s = null;
	public Communication(Socket accept) {
		// TODO Auto-generated constructor stub
		s = accept;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
